<?php
    $nome = $_POST["name"];
    $telefone = $_POST["tel"];
    $email = $_POST["email"];
    $endereco = $_POST["end"];

    $ensfund = $_POST["efc"];
    $ensmed = $_POST["emc"];
    $enssup = $_POST["esc"];
    $grad = $_POST["gc"];
    $posgrad = $_POST["pgc"];

    $exp = $_POST["exp"];
    $dataa = $_POST["dta"];
    $datad = $_POST["dtd"];
    $funex = $_POST["fe"];

    $desc = $_POST["desc"];
    $horas = $_POST["hrs"];
    $anoconc = $_POST["anoc"];

    $info = $_POST["info"];

    echo "DADOS PESSOAIS";
    echo $nome;
    echo $telefone;
    echo $email;
    echo $endereco;
    
    echo "ESCOLARIDADE";
    echo $ensfund;
    echo $ensmed;
    echo $enssup;
    echo $grad;
    echo $posgrad;

    echo "EXPERIÊNCIA PROFISSIONAL";
    echo $exp;
    echo $dataa;
    echo $datad;
    echo $funex;

    echo "CURSOS E IDIOMAS";
    echo $desc;
    echo $horas;
    echo $anoconc;
    
    echo "INFORMAÇÕES ADCIONAIS";
    echo $info;

?>